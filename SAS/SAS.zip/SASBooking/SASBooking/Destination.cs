﻿namespace SASBooking
{
	public enum Destination
	{
		Copenhagen,
		Oslo,
		Aarhus,
		Beijing,
		HongKong
	}
}