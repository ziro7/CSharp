﻿using System;

namespace Smartlearning
{
	class Teacher
	{
		public String Name { get; set; }

		public Teacher(string teacherName)
		{
			Name = teacherName;
		}
	}

}