﻿namespace Archive
{
	public enum MessageType
	{
		Error,
		Info
	}
}