﻿namespace Archive
{
	public enum School
	{
		CbsBussiness,
		SmartLearning,
		AarhusUniversity,
		AalborgUniversity,
		SyddanskUniversity
	}
}

